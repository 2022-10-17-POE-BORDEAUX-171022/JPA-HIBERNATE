package com.webstart.demo.repository;

import com.webstart.demo.config.PersistenceConfigTest;
import com.webstart.demo.entity.Movie;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(SpringExtension.class) // permet d'exécuter notre classe de test dans un context spring
@ContextConfiguration(classes = {PersistenceConfigTest.class}) // classes de configuration requis pour l'initialisation de nos tests
@SqlConfig(dataSource = "dataSourceH2", transactionManager = "transactionManager") // permet à spring d'insérer des données via le data source et le transaction manager configuré dans PersistenceConfigTest
@Sql({"/datas/data-test.sql"}) // chager le fichier qui va insérer des données en BDD
public class MovieRepositoryTest {

    @Autowired
    private MovieRepository repository;

    @Test
    public void save_casNominal() {
        Movie movie = new Movie(); // état TRANSIENT
        movie.setName("Training Day"); // à ce stade on a créé un movie mais on ne l'a pas encore donné au contexte de persistence
        repository.persist(movie);
        System.out.println("Fin de test");
    }

    @Test
    public void find_casNominal() {
        Movie movie = repository.find(-2L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Boyz in the hood");
        // débugger les logs
        // regarder si l'entity manager contient notre entité
        // regarder si une session a été ouverte

    }

    // SELECT ALL
    // implémenter une autre méthode qui permet de récupérer tous les films
    // un format qu'on appel JPQL (un langage proche du SQL)
    // vérifier côté tests unitaires si on récupère bien deux films

    // UPDATE
    // faire une modification
    // modifier le nom du deuxième film -> Boyz in the hood 2
    // vérifier que la modificaiton a fonctionné

    // DELETE
    // gérer la suppression du premier film par exemple
    // et vérifier qu'en base on a plus qu'un seul film

}
