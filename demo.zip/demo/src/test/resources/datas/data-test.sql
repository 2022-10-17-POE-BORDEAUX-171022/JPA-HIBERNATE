INSERT INTO Movie (id, name) values (-1L, 'Un prophète');
INSERT INTO Movie (id, name) values (-2L, 'Boyz in the hood');