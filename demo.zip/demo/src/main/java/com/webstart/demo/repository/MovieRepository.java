package com.webstart.demo.repository;

import com.webstart.demo.entity.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Repository
public class MovieRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);

    @PersistenceContext // le context va nous permettre de gérer les différents états de nos entités
    EntityManager entityManager;
    // API qui est utilisée pour créer et supprimer des instances de peristance de données
    // pour trouver les entités avec leur clef primaire (id)
    // ou même pour faire des requêtes via nos entités

    @Transactional
    public void persist(Movie movie) {
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        entityManager.persist(movie); // Etat Managed
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
    }

    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        return movie;
    }

}
