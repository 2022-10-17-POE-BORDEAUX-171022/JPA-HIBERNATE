package com.webstart.demo.repository;

import com.webstart.demo.entity.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class MovieRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);

    @PersistenceContext // le context va nous permettre de gérer les différents états de nos entités
    EntityManager entityManager;
    // API qui est utilisée pour créer et supprimer des instances de peristance de données
    // pour trouver les entités avec leur clef primaire (id)
    // ou même pour faire des requêtes via nos entités

    @Transactional
    public void persist(Movie movie) {
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        entityManager.persist(movie); // Etat Managed
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
    }

    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        return movie;
    }

    public List<Movie> getAll() {
        // SELECT * FROM movie en JPQL
        return entityManager.createQuery("from Movie", Movie.class).getResultList();
    }

    @Transactional
    public Movie merge(Movie movie) {
        return entityManager.merge(movie);
    }

    @Transactional
    public void remove(Long id) {
        // je récupère mon entité Movie via son id
        Movie movie = entityManager.find(Movie.class, id);
        // je supprime l'entité récupérée
        entityManager.remove(movie);
    }

    @Transactional
    public Movie getReference(Long id) {
        Movie movie = entityManager.getReference(Movie.class, id);
        LOGGER.trace("MOVIE NAME : " + movie.getName());
        return movie;
    }

    public Movie getReference2(Long id) {
        return entityManager.getReference(Movie.class, id);
        // throw new ArithmeticException("error");
    }

    @Transactional
    public void persist2(Movie movie) {
        entityManager.persist(movie); // Etat Managed
        entityManager.flush();
    }

    @Transactional
    public void remove2(Long id) {

        // Cache de premier niveau
        Movie movie = entityManager.find(Movie.class, id); // ici je vais faire un selec en base
        Movie movie2 = entityManager.find(Movie.class, id); // à partir d'ici vu que je connais déjà l'entité je vais la récupérer dans son cache
        Movie movie3 = entityManager.find(Movie.class, id);

        entityManager.remove(movie);
    }

    @Transactional
    public Movie merge2(Movie movie) {
        Movie myMovie = entityManager.find(Movie.class, movie.getId()); // je triche un peu je fais déjà un select alors que le merge est censé le faire que se passe til?
        return entityManager.merge(movie);
    }

}
